import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import io

from os import listdir
from os.path import isfile, join

from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn import preprocessing

from itertools import repeat

subsample_og_data = 2

test1filepath = "Data\\IMS\\1st_test"
test2filepath = "Data\\IMS\\2nd_test\\2nd_test"
test3filepath = "Data\\IMS\\3rd_test\\4th_test\\txt"

test1_column_names = ["Test 1 Bearing 1", "Test 1 Bearing 1Y", "Test 1 Bearing 2", "Test 1 Bearing 2Y", "Test 1 Bearing 3", "Test 1 Bearing 3Y", "Test 1 Bearing 4", "Test 1 Bearing 4Y"]
test2_column_names = ["Test 2 Bearing 1", "Test 2 Bearing 2", "Test 2 Bearing 3", "Test 2 Bearing 4"]
test3_column_names = ["Test 3 Bearing 1", "Test 3 Bearing 2", "Test 3 Bearing 3", "Test 3 Bearing 4"]

#test1_column_names = [x for item in test1_column_names for x in repeat(item, subsample_og_data)]
#test2_column_names = [x for item in test2_column_names for x in repeat(item, subsample_og_data)]
#test3_column_names = [x for item in test3_column_names for x in repeat(item, subsample_og_data)]
#%%
def import_data_files(test_filepath, column_names):
  filenames = [test_filepath+"/"+f for f in listdir(test_filepath) if isfile(join(test_filepath, f))]
  filenames.sort() # sort the filenames to ensure they are in the right order
  #if test_filepath == "1st_test":
  #  dataframes = [pd.read_csv(f, sep = '\t', header=None, names=column_names, usecols = ["Bearing 1", "Bearing 2", "Bearing 3", "Bearing 4"]) for f in filenames]
  #else:
  dataframes = [pd.read_csv(f, sep = '\t', header=None, names=column_names) for f in filenames]
  return dataframes


test1_df = import_data_files(test1filepath, test1_column_names)
test2_df = import_data_files(test2filepath, test2_column_names)
test3_df = import_data_files(test3filepath, test3_column_names)


#%%
print(test1_df[0])
print(len(test3_df))

#%%

n = 984 # number of data points

test1 = []
for i, df in enumerate(test1_df):
    row = [];
    for column in df:
        #row.append(np.var(df[column].iloc[:round(len(df[column])/subsample_og_data)]))
        #row.append(np.var(df[column].iloc[round(len(df[column])/subsample_og_data):]))       
        row.append(np.var(df[column]))
    if i >= len(test1_df) - n:
        test1.append(row)
    
    
test2 = []
for i, df in enumerate(test2_df):
    row = [];
    for column in df:
        #row.append(np.var(df[column].iloc[:round(len(df[column])/subsample_og_data)]))
        #row.append(np.var(df[column].iloc[round(len(df[column])/subsample_og_data):]))
        row.append(np.var(df[column]))
    if i >= len(test2_df) - n:
        test2.append(row)
    
    
test3 = []
for i, df in enumerate(test3_df):
    row = [];
    for column in df:
        #row.append(np.var(df[column].iloc[:round(len(df[column])/subsample_og_data)]))
        #row.append(np.var(df[column].iloc[round(len(df[column])/subsample_og_data):]))   
        row.append(np.var(df[column]))
    if i >= len(test3_df) - n:
        test3.append(row)


#%%

test1 = np.array(test1).T
test2 = np.array(test2).T
test3 = np.array(test3).T


#%%

all_data = [test1, test2, test3]

#%%

column_names = [test1_column_names , test2_column_names , test3_column_names]


#%%


data = pd.DataFrame()
for i, test in enumerate(all_data):
    for j, bearing_activity in enumerate(test):
        new = pd.DataFrame({column_names[i][j] : bearing_activity})
        data = pd.concat([data, new], axis=1)
         

        

data.to_csv('activity_data.csv', index=False)